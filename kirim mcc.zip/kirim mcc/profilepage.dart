import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool showSavedCards = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: EdgeInsets.only(top: 15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(32),
            topRight: Radius.circular(32),
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Displaying username on the top left
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Username',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        // Displaying "@username"
                        Text(
                          '@username',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),

                    // Logout button on the top right
                    IconButton(
                      icon: Icon(Icons.logout),
                      onPressed: () {
                        // Add your logout functionality here
                        // For example, you can navigate to the login page
                      },
                    ),
                  ],
                ),

                SizedBox(height: 30,),

                // Add a horizontal line (Divider)
                Divider(
                  height: 5, // Adjusted height to reduce space
                  thickness: 2,
                  color: Colors.grey,
                ),

                // Container to move the entire row up
                Container(
                  // Adjust the top padding
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            showSavedCards = true;
                          });
                        },
                        child: Text(
                          'SAVED CARDS',
                          style: TextStyle(
                            color: showSavedCards ? Colors.black : Colors.grey[700],
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          primary: Colors.white,
                          elevation: 0,
                        ),
                      ),

                      // Vertical line touching the horizontal divider
                      Container(
                        height: 30, // Adjust the height according to your design
                        width: 2,
                        color: Colors.grey,
                      ),

                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            showSavedCards = false;
                          });
                        },
                        child: Text(
                          'LIKED CARDS',
                          style: TextStyle(
                            color: showSavedCards ? Colors.grey[700] : Colors.black,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          primary: Colors.white,
                          elevation: 0,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 16),

                // Saved Cards or Liked Cards content
                showSavedCards ? _buildSavedCards() : _buildLikedCards(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ...

Widget _buildCardContainerLiked() {
  return Container(
    decoration: BoxDecoration(
      color: Colors.grey[800], // Dark grey color
      borderRadius: BorderRadius.circular(8.0),
      border: Border.all(color: Colors.black, width: 1.0),
    ),
  );
}

Widget _buildCardContainerSaved() {
  return Container(
    decoration: BoxDecoration(
      color: Colors.grey[800], // Dark grey color
      borderRadius: BorderRadius.circular(8.0),
      border: Border.all(color: Colors.black, width: 1.0),
    ),
  );
}

// ...


  Widget _buildSavedCards() {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 8.0,
        mainAxisSpacing: 8.0,
      ),
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: 4, // Replace with the actual number of saved cards
      itemBuilder: (context, index) {
        return _buildCardContainerSaved();
      },
    );
  }

  Widget _buildLikedCards() {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 8.0,
        mainAxisSpacing: 8.0,
      ),
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: 4, // Replace with the actual number of liked cards
      itemBuilder: (context, index) {
        return _buildCardContainerLiked();
      },
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: ProfilePage(),
  ));
}
