import 'package:flutter/material.dart';

class Card4 extends StatelessWidget {
  Card4({Key? key}) : super(key: key);

  final Color myCustomColor = Color(0xFFB10000);
  final int harga = 650;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            alignment: Alignment.topRight,
            margin: const EdgeInsets.only(
              top: 5,
              right: 10,
            ),
            child: TextButton(
              onPressed: () {},
              child: Text(
                "BUY",
                style: TextStyle(color: Colors.white),
              ),
              style: TextButton.styleFrom(
                padding: EdgeInsets.zero,
                backgroundColor: myCustomColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
          ),
          Expanded(
              child: Transform.scale(
                scale: 1.2, // Adjust the scale factor as needed
                child: Image.asset('assets/3.png'),
              ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            child: Text(
              'LAVA FREDDY',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.black,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 20, 10),
            child: Text(
              'Unlike the other animatronics, Lava Freddy does not reset upon being flashed. Instead, he is only halted.',
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 12,
                color: Colors.black.withOpacity(0.53),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 5),
            child: Row(
              children: [
                Text(
                  '\$' '$harga',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Colors.black,
                  ),
                ),
                Spacer(),
                IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.favorite_border_rounded),
                  color: Colors.red,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
