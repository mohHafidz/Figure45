import 'package:aol2/page/card1.dart';
import 'package:aol2/page/card2.dart';
import 'package:aol2/page/card3.dart';
import 'package:aol2/page/card4.dart';
import 'package:aol2/page/card5.dart';
import 'package:aol2/page/card6.dart';
import 'package:aol2/page/card7.dart';
import 'package:aol2/page/card8.dart';
import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        scrollDirection: Axis.vertical,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  'BUY ',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Icon(
                  Icons.circle,
                  color: Colors.white,
                  size: 20,
                ),
                Text(
                  ' DISCOVER ',
                  style: TextStyle(fontSize: 28),
                ),
                Icon(
                  Icons.circle,
                  color: Colors.white,
                  size: 20,
                ),
                Text(
                  ' COLLECT',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: MediaQuery.of(context).size.height / 1.5,
            child: GridView.count(
              primary: false,
              padding: const EdgeInsets.all(20),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 0.43,
              crossAxisCount: 2,
              children: <Widget>[
                Card1(),
                Card2(),
                Card3(),
                Card4(),
                Card5(),
                Card6(),
                Card7(),
                Card8()
              ],
            ),
          ),
        ],
      ),
    );
  }
}
